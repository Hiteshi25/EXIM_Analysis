import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.ensemble import RandomForestRegressor

st.set_page_config(page_title="EXIM Dashboard", layout="wide")

# ---------------- LOAD DATA ----------------
with st.spinner("Loading data..."):
    df = pd.read_csv("C:\\Users\\hites\\OneDrive\\Documents\\EXIM ANALYSIS\\CODE\\exim_data.csv")

# 🔥 NEW: Create Date column
df['Date'] = pd.to_datetime(df['Year'].astype(str) + '-' + df['Month'])

# ---------------- HEADER ----------------
st.markdown("""
<h1 style='text-align: center;'> EXIM TRADE DASHBOARD</h1>
<p style='text-align: center; color: gray;'>Advanced Trade Analysis System</p>
""", unsafe_allow_html=True)

st.markdown("---")

# ---------------- SIDEBAR ----------------
st.sidebar.header("🔍 Filters")

country = st.sidebar.selectbox("Country", df['Country'].unique())
partner = st.sidebar.selectbox("Partner", df['Partner'].unique())

df_kpi = df[(df['Country'] == country) & (df['Partner'] == partner)]

# ---------------- KPIs ----------------
total = df_kpi['Value_USD_Mn'].sum()
export = df_kpi[df_kpi['Trade_Type']=="Export"]['Value_USD_Mn'].sum()
import_val = df_kpi[df_kpi['Trade_Type']=="Import"]['Value_USD_Mn'].sum()
trade_balance = export - import_val

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Trade", f"{int(total):,}")
c2.metric("Export", f"{int(export):,}", delta="📈")
c3.metric("Import", f"{int(import_val):,}", delta="📉")
c4.metric("Balance", f"{int(trade_balance):,}",
          delta="Surplus" if trade_balance > 0 else "Deficit")

st.markdown(f"""
### 🌍 {country} Trade Overview

- 📈 Export is **{int(export):,}**
- 📉 Import is **{int(import_val):,}**
- ⚖️ Balance is **{'Surplus' if trade_balance > 0 else 'Deficit'}**
""")

# ---------------- TABS ----------------
tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Overview",
    "🌍 Country Analysis",
    "📦 Commodity Analysis",
    "📈 Prediction"
])

# ---------------- TAB 1 ----------------
with tab1:

    st.subheader("Trade Distribution")

    trade = df_kpi.groupby('Trade_Type')['Value_USD_Mn'].sum().reset_index()

    fig = px.pie(
        trade,
        names='Trade_Type',
        values='Value_USD_Mn',
        hole=0.5,
        template="plotly_dark"
    )
    st.plotly_chart(fig, use_container_width=True)

    # 🔥 NEW: Monthly Trend
    st.subheader("Monthly Trade Trend")

    df_trend = df[df['Country'] == country]

    monthly = df_trend.groupby('Date')['Value_USD_Mn'].sum().reset_index()

    fig = px.line(
        monthly,
        x='Date',
        y='Value_USD_Mn',
        markers=True,
        template="plotly_dark"
    )
    st.plotly_chart(fig, use_container_width=True)

    # 🔥 NEW: Seasonal Analysis
    st.subheader("Best Trading Months")

    month_analysis = df_trend.groupby('Month')['Value_USD_Mn'].sum().reset_index()

    fig = px.bar(
        month_analysis,
        x='Month',
        y='Value_USD_Mn',
        color='Month',
        template="plotly_dark"
    )
    st.plotly_chart(fig, use_container_width=True)

# ---------------- TAB 2 ----------------
with tab2:

    st.subheader("Country vs Partner Heatmap")

    pivot = df.pivot_table(
        values='Value_USD_Mn',
        index='Country',
        columns='Partner',
        aggfunc='sum'
    )

    fig = px.imshow(pivot, aspect="auto", template="plotly_dark")
    st.plotly_chart(fig, use_container_width=True)

# ---------------- TAB 3 ----------------
with tab3:

    st.subheader("Commodity Trade Explorer")

    rep_country = st.selectbox("Reporter Country", df['Country'].unique())

    df_rep = df[df['Country'] == rep_country]

    partner_options = df_rep['Partner'].unique()
    partner_country = st.selectbox("Partner Country", partner_options)

    df_filtered = df[
        (df['Country'] == rep_country) &
        (df['Partner'] == partner_country)
    ]

    commodity_options = df_filtered['Commodity_Name'].unique()
    commodity = st.selectbox("Commodity", commodity_options)

    df_final = df[
        (df['Country'] == rep_country) &
        (df['Partner'] == partner_country) &
        (df['Commodity_Name'] == commodity)
    ]

    if df_final.empty:
        st.warning("No data available")
    else:
    # 🔥 1. TREND (BEST ANALYSIS)
        st.subheader("Trade Trend (Export vs Import)")

        trend = df_final.groupby(['Date', 'Trade_Type'])['Value_USD_Mn'].sum().reset_index()

        fig = px.line(
            trend,
            x='Date',
            y='Value_USD_Mn',
            color='Trade_Type',
            markers=True,
            template="plotly_dark"
        )

        st.plotly_chart(fig, use_container_width=True)

        # 🔥 2. DONUT (DISTRIBUTION)
        st.subheader("Trade Distribution")

        trade_type = df_final.groupby('Trade_Type')['Value_USD_Mn'].sum().reset_index()

        fig2 = px.pie(
            trade_type,
            names='Trade_Type',
            values='Value_USD_Mn',
            hole=0.6,
            color='Trade_Type',
            template="plotly_dark"
        )

        st.plotly_chart(fig2, use_container_width=True)

        # 🔥 3. KPI (NET TRADE)
        export_val = df_final[df_final['Trade_Type']=="Export"]['Value_USD_Mn'].sum()
        import_val = df_final[df_final['Trade_Type']=="Import"]['Value_USD_Mn'].sum()

        st.subheader("Trade Summary")

        c1, c2, c3 = st.columns(3)

        c1.metric("Export", f"{int(export_val):,}")
        c2.metric("Import", f"{int(import_val):,}")

        c3.metric(
            "Net Trade",
            f"{int(export_val - import_val):,}",
            delta="Surplus" if export_val > import_val else "Deficit"
        )

# ---------------- TAB 4 ----------------
with tab4:

    st.subheader("Time-based Prediction")

    df_t = df[df['Country'] == country].copy()

    df_t = df_t.sort_values(by='Date')

    df_t['Time'] = range(len(df_t))

    X = df_t[['Time']]
    y = df_t['Value_USD_Mn']

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)

    df_t['Predicted'] = model.predict(X)

    future = pd.DataFrame({'Time': range(len(df_t), len(df_t)+6)})
    future['Predicted'] = model.predict(future)

    future_dates = pd.date_range(start=df_t['Date'].max(), periods=6, freq='M')

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=df_t['Date'],
        y=df_t['Value_USD_Mn'],
        name="Actual",
        mode='lines+markers'
    ))

    fig.add_trace(go.Scatter(
        x=df_t['Date'],
        y=df_t['Predicted'],
        name="Predicted",
        line=dict(dash='dash')
    ))

    fig.add_trace(go.Scatter(
        x=future_dates,
        y=future['Predicted'],
        name="Future",
        line=dict(dash='dot')
    ))

    fig.update_layout(template="plotly_dark")

    st.plotly_chart(fig, use_container_width=True)

# ---------------- DOWNLOAD ----------------
st.download_button(
    "Download Data",
    df.to_csv(index=False),
    file_name="trade_data.csv"
)