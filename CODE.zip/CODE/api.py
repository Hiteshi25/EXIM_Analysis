import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(layout="wide")

# ---------------- LOAD ----------------
df = pd.read_csv("C:\\Users\\hites\\OneDrive\\Documents\\EXIM ANALYSIS\\CODE\\exim_data.csv")
df['Date'] = pd.to_datetime(df['Year'].astype(str) + '-' + df['Month'])

# ---------------- HEADER ----------------
st.markdown("<h1 style='margin-bottom:0'>🌍 EXIM TRADE ANALYTICS</h1>", unsafe_allow_html=True)

# ---------------- FILTER BAR ----------------
c1, c2 = st.columns([2,2])

country = c1.selectbox("Country", df['Country'].unique())
partner = c2.selectbox("Partner", df['Partner'].unique())

df_filtered = df[(df['Country']==country) & (df['Partner']==partner)]

# ---------------- KPI ROW ----------------
export = df_filtered[df_filtered['Trade_Type']=="Export"]['Value_USD_Mn'].sum()
import_val = df_filtered[df_filtered['Trade_Type']=="Import"]['Value_USD_Mn'].sum()
balance = export - import_val

k1, k2, k3 = st.columns(3)

k1.metric("Export", int(export))
k2.metric("Import", int(import_val))
k3.metric("Balance", int(balance))

st.markdown("---")

# ---------------- GRAPH SECTION ----------------
g1, g2 = st.columns([2,1])

# LEFT → TREND
with g1:
    st.subheader("📈 Trade Trend")

    trend = df_filtered.groupby(['Date','Trade_Type'])['Value_USD_Mn'].sum().reset_index()

    fig = px.line(
        trend,
        x='Date',
        y='Value_USD_Mn',
        color='Trade_Type'
    )

    st.plotly_chart(fig, use_container_width=True)

# RIGHT → PIE
with g2:
    st.subheader("📊 Distribution")

    trade = df_filtered.groupby('Trade_Type')['Value_USD_Mn'].sum().reset_index()

    fig = px.pie(trade, names='Trade_Type', values='Value_USD_Mn')
    st.plotly_chart(fig, use_container_width=True)