import streamlit as st
import pandas as pd
import requests
import plotly.express as px
from sklearn.ensemble import RandomForestRegressor
import plotly.graph_objects as go

st.set_page_config(page_title="EXIM Dashboard", layout="wide")

# ================= API FUNCTION =================

@st.cache_data
def load_data(country, year, flow):
    url = "https://comtradeapi.un.org/public/v1/get/HS"

    params = {
        "reporterCode": country,
        "period": year,
        "flowCode": flow,
        "cmdCode": "AG6"
    }

    response = requests.get(url, params=params)
    data = response.json()

    if 'data' not in data or len(data['data']) == 0:
        return pd.DataFrame()

    df = pd.DataFrame(data['data'])

    df.rename(columns={
        'reporterDesc': 'Country',
        'partnerDesc': 'Partner',
        'cmdDesc': 'Commodity_Name',
        'primaryValue': 'Value_USD_Mn'
    }, inplace=True)

    return df


# ================= GLOBAL FILTERS =================

st.title("🌍 EXIM TRADE DASHBOARD")

country_code = st.selectbox("Select Country", {"India": "356", "USA": "840"})
year = st.selectbox("Select Year", ["2022", "2021"])   # ⚠️ use stable years
flow = st.selectbox("Trade Type", {"Export": "X", "Import": "M"})

df = load_data(country_code, year, flow)

if df.empty:
    st.error("No data found ❌ Try different year")
    st.stop()

df['Trade_Type'] = "Export" if flow == "X" else "Import"

# ================= KPI FILTER =================

st.subheader("Overview Filters")

col1, col2 = st.columns(2)

with col1:
    country_filter = st.selectbox("Country", df['Country'].unique())

with col2:
    partner = st.selectbox("Partner", df['Partner'].unique())

df_kpi = df[(df['Country'] == country_filter) & (df['Partner'] == partner)]

# ================= KPI =================

total = df_kpi['Value_USD_Mn'].sum()
export = df_kpi[df_kpi['Trade_Type'] == "Export"]['Value_USD_Mn'].sum()
import_val = df_kpi[df_kpi['Trade_Type'] == "Import"]['Value_USD_Mn'].sum()

c1, c2, c3 = st.columns(3)
c1.metric("Total Trade", f"{int(total):,}")
c2.metric("Export", f"{int(export):,}")
c3.metric("Import", f"{int(import_val):,}")

st.markdown("---")

# ================= DONUT =================

st.subheader("Trade Distribution")

trade = df.groupby('Trade_Type')['Value_USD_Mn'].sum().reset_index()

fig = px.pie(trade, names='Trade_Type', values='Value_USD_Mn', hole=0.5)
st.plotly_chart(fig, use_container_width=True)

# ================= TOP 5 =================

st.subheader("Top 5 Partners")

top = df.groupby('Partner')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)

fig = px.bar(top.reset_index(), x='Partner', y='Value_USD_Mn')
st.plotly_chart(fig, use_container_width=True)

# ================= TOP COMMODITIES =================

st.subheader("Top 5 Commodities")

top_com = df.groupby('Commodity_Name')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)

fig = px.bar(top_com.reset_index(), x='Commodity_Name', y='Value_USD_Mn')
st.plotly_chart(fig, use_container_width=True)

# ================= TREND =================

st.subheader("Trend Prediction")

df_t = df.groupby('Commodity_Name')['Value_USD_Mn'].sum().reset_index()

df_t['Index'] = range(len(df_t))

X = df_t[['Index']]
y = df_t['Value_USD_Mn']

model = RandomForestRegressor()
model.fit(X, y)

df_t['Predicted'] = model.predict(X)

fig = go.Figure()

fig.add_trace(go.Scatter(x=df_t['Index'], y=df_t['Value_USD_Mn'], name="Actual"))
fig.add_trace(go.Scatter(x=df_t['Index'], y=df_t['Predicted'], name="Predicted"))

st.plotly_chart(fig, use_container_width=True)