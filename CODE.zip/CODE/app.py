# import streamlit as st
# import pandas as pd
# import matplotlib.pyplot as plt
# from sklearn.ensemble import RandomForestRegressor
# import plotly.express as px

# # Page config
# st.set_page_config(page_title="EXIM Dashboard", layout="wide")

# # Load data
# df = pd.read_csv(r"C:\Users\hites\OneDrive\Documents\EXIM ANALYSIS\Data\data.csv")

# # ---------------- HEADER ----------------
# st.markdown("""
# <h1 style='text-align: center;'>EXIM TRADE DASHBOARD</h1>
# <p style='text-align: center; color: gray;'>Analyze trade trends, partners, and commodities</p>
# """, unsafe_allow_html=True)

# st.markdown("---")

# # ---------------- SIDEBAR ----------------
# st.sidebar.header("Filters")

# view = st.sidebar.radio("View By", ["Country", "Partner"])

# if view == "Country":
#     selected = st.sidebar.selectbox("Select Country", df['Country'].unique())
#     df_filtered = df[df['Country'] == selected]
# else:
#     selected = st.sidebar.selectbox("Select Partner", df['Partner'].unique())
#     df_filtered = df[df['Partner'] == selected]



# # ---------------- KPI ----------------
# total = df_filtered['Value_USD_Mn'].sum()
# export = df_filtered[df_filtered['Trade_Type']=="Export"]['Value_USD_Mn'].sum()
# import_val = df_filtered[df_filtered['Trade_Type']=="Import"]['Value_USD_Mn'].sum()

# col1, col2, col3 = st.columns(3)
# col1.metric("Total Trade", f"{int(total):,}")
# col2.metric("Export Value", f"{int(export):,}")
# col3.metric("Import Value", f"{int(import_val):,}")

# st.markdown("---")

# # ---------------- ROW 1 ----------------
# col4, col5 = st.columns(2)

# # Bar chart (Import vs Export)

# with col4:
#     st.subheader("Import vs Export Analysis")
#     trade = df_filtered.groupby('Trade_Type')['Value_USD_Mn'].sum()
    
#     fig, ax = plt.subplots()
#     colors = ['black', 'red']  # Import, Export
#     trade.plot(kind='bar', ax=ax, color=colors)
#     ax.set_title("Import vs Export Analysis")
#     ax.set_ylabel("Value (USD Mn)")
#     st.pyplot(fig)

# # Pie chart
# with col5:
#     st.subheader("Trade Distribution")
    
#     fig2, ax2 = plt.subplots()
#     colors = ['black', 'red']
#     ax2.pie(trade, labels=trade.index, autopct='%1.1f%%', colors=colors)
#     ax2.set_title("Trade Distribution")
#     st.pyplot(fig2)

# # ---------------- ROW 2 ----------------
# col6, col7 = st.columns(2)


# # Top Partners / Countries
# with col6:
#     st.subheader("Top 5 Trading Analysis")
    
#     if view == "Country":
#         top = df.groupby('Partner')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)
#     else:
#         top = df.groupby('Country')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)
    
#     fig = px.bar(
#     x=top.index,
#     y=top.values,
#     labels={'x': '', 'y': 'Value'},
#     title="Top 5 Trading Analysis",
#     hover_name=top.index
#     )

#     # Remove x-axis labels
#     fig.update_layout(xaxis_showticklabels=False)

#     st.plotly_chart(fig, use_container_width=True)

# # Commodity Analysis
# with col7:
#     st.subheader("Top Commodities")
    
#     top_com = df_filtered.groupby('Commodity_Name')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)
    
#     fig = px.bar(
#     x=top_com.index,
#     y=top_com.values,
#     labels={'x': '', 'y': 'Value'},
#     title="Top Commodities",
#     hover_name=top_com.index
#     )

#     # Remove x-axis labels
#     fig.update_layout(xaxis_showticklabels=False)
#     st.plotly_chart(fig, use_container_width=True)

# st.markdown("---")

# # ---------------- TREND GRAPH ----------------
# st.subheader("Trade Trend & Prediction")

# df_filtered = df_filtered.reset_index(drop=True)
# df_filtered['Month_Num'] = range(len(df_filtered))

# X = df_filtered[['Month_Num']]
# y = df_filtered['Value_USD_Mn']

# model = RandomForestRegressor(n_estimators=100, random_state=42)
# model.fit(X, y)

# df_filtered['Predicted'] = model.predict(X)

# fig5, ax5 = plt.subplots()
# ax5.plot(df_filtered['Month_Num'], df_filtered['Value_USD_Mn'], 
#          color='blue', linewidth=2, label='Actual')

# ax5.plot(df_filtered['Month_Num'], df_filtered['Predicted'], 
#          color='orange', linestyle='--', linewidth=2, label='Predicted')
# ax5.set_title("Trade Trend & Prediction")
# ax5.legend()

# st.pyplot(fig5)

# st.markdown("---")

# # Footer
# st.markdown("<center>EXIM Analysis Dashboard | Developed by Hiteshi</center>", unsafe_allow_html=True)






# import streamlit as st
# import pandas as pd
# import matplotlib.pyplot as plt
# from sklearn.ensemble import RandomForestRegressor
# import plotly.express as px

# # Page config

# st.set_page_config(page_title="EXIM Dashboard", layout="wide")

# # Load data

# df = pd.read_csv(r"C:\Users\hites\OneDrive\Documents\EXIM ANALYSIS\Data\data.csv")

# # ---------------- HEADER ----------------

# st.markdown("""

# <h1 style='text-align: center;'>EXIM TRADE DASHBOARD</h1>
# <p style='text-align: center; color: gray;'>Analyze trade trends, partners, and commodities</p>
# """, unsafe_allow_html=True)

# st.markdown("---")

# # ---------------- FILTERS ----------------

# st.sidebar.header("Filters")

# view = st.sidebar.radio("View By", ["Country", "Partner"])

# if view == "Country":
#     selected = st.sidebar.selectbox("Select Country", df['Country'].unique())
#     df_filtered = df[df['Country'] == selected]
# else:
#     selected = st.sidebar.selectbox("Select Partner", df['Partner'].unique())
#     df_filtered = df[df['Partner'] == selected]

# # Handle empty data

# if df_filtered.empty:
#     st.warning("No data available for selected filters")
#     st.stop()

# # ---------------- KPI ----------------

# total = df_filtered['Value_USD_Mn'].sum()
# export = df_filtered[df_filtered['Trade_Type']=="Export"]['Value_USD_Mn'].sum()
# import_val = df_filtered[df_filtered['Trade_Type']=="Import"]['Value_USD_Mn'].sum()

# col1, col2, col3 = st.columns(3)
# col1.metric("Total Trade", f"{int(total):,}")
# col2.metric("Export Value", f"{int(export):,}")
# col3.metric("Import Value", f"{int(import_val):,}")

# st.markdown("---")

# # ---------------- ROW 1 ----------------

# col4, col5 = st.columns(2)

# with col4:
#     st.subheader("Import vs Export Analysis")

# trade = df_filtered.groupby('Trade_Type')['Value_USD_Mn'].sum()
# trade = trade.reindex(['Import', 'Export'], fill_value=0)

# fig, ax = plt.subplots()
# trade.plot(kind='bar', ax=ax, color=['black', 'red'])
# st.pyplot(fig)

# with col5:
#     st.subheader("Trade Distribution")

# # Force both values for pie
# trade_fixed = trade.copy()
# trade_fixed[trade_fixed == 0] = 0.0001

# fig2, ax2 = plt.subplots()
# ax2.pie(trade_fixed, labels=trade.index,
#         autopct='%1.1f%%', colors=['black', 'red'])
# st.pyplot(fig2)

# # ---------------- ROW 2 ----------------

# col6, col7 = st.columns(2)

# # Top 5 Trading

# with col6:
#     st.subheader("Top 5 Trading Analysis")

# view2 = st.selectbox("View By", ["Country", "Partner"], key="top1")

# if view2 == "Country":
#     top = df.groupby('Partner')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)
# else:
#     top = df.groupby('Country')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)

# top_df = top.reset_index()
# top_df.columns = ['Name', 'Value']

# fig = px.bar(
#     top_df,
#     x='Name',
#     y='Value',
#     hover_name='Name',
#     color='Name'
# )

# fig.update_layout(xaxis_showticklabels=False)
# st.plotly_chart(fig, width='stretch')

# # Commodity Analysis

# with col7:
#     st.subheader("Top Commodities")

# top_com = df_filtered.groupby('Commodity_Name')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)

# top_com_df = top_com.reset_index()
# top_com_df.columns = ['Commodity', 'Value']

# fig = px.bar(
#     top_com_df,
#     x='Commodity',
#     y='Value',
#     hover_name='Commodity',
#     color='Commodity'
# )

# fig.update_layout(xaxis_showticklabels=False)
# st.plotly_chart(fig, width='stretch')

# st.markdown("---")

# # ---------------- TREND GRAPH ----------------

# st.subheader("Trade Trend & Prediction")

# df_t = df_filtered.reset_index(drop=True).copy()
# df_t['Month_Num'] = range(len(df_t))

# X = df_t[['Month_Num']]
# y = df_t['Value_USD_Mn']

# model = RandomForestRegressor(n_estimators=100, random_state=42)
# model.fit(X, y)

# df_t['Predicted'] = model.predict(X)

# fig5, ax5 = plt.subplots()
# ax5.plot(df_t['Month_Num'], df_t['Value_USD_Mn'], color='blue', label='Actual')
# ax5.plot(df_t['Month_Num'], df_t['Predicted'], color='orange', linestyle='--', label='Predicted')
# ax5.legend()

# st.pyplot(fig5)

# st.markdown("---")

# # Footer

# st.markdown("<center>EXIM Analysis Dashboard | Developed by Hiteshi</center>", unsafe_allow_html=True)


import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
import plotly.express as px

st.set_page_config(page_title="EXIM Dashboard", layout="wide")

df = pd.read_csv(r"C:\Users\hites\OneDrive\Documents\EXIM ANALYSIS\CODE\data_121.csv")

# ---------------- HEADER ----------------

st.markdown("""

<h1 style='text-align: center;'>EXIM TRADE DASHBOARD</h1>
<p style='text-align: center; color: gray;'>Analyze trade trends, partners, and commodities</p>
""", unsafe_allow_html=True)

st.markdown("---")


# ---------------- KPI FILTER ----------------

st.subheader("Overview Filters")

c1, c2 = st.columns(2)
with c1:
    country = st.selectbox("Country", df['Country'].unique(), key="k1")
with c2:
    partner = st.selectbox("Partner", df['Partner'].unique(), key="k2")

df_kpi = df[(df['Country'] == country) & (df['Partner'] == partner)]

# ---------------- KPI ----------------

total = df_kpi['Value_USD_Mn'].sum()
export = df_kpi[df_kpi['Trade_Type']=="Export"]['Value_USD_Mn'].sum()
import_val = df_kpi[df_kpi['Trade_Type']=="Import"]['Value_USD_Mn'].sum()

col1, col2, col3 = st.columns(3)
col1.metric("Total Trade", f"{int(total):,}")
col2.metric("Export Value", f"{int(export):,}")
col3.metric("Import Value", f"{int(import_val):,}")

st.markdown("---")

# ---------------- ROW 1 ----------------

st.subheader("Overall Trade Distribution")

# Clean data
df_clean = df.dropna(subset=['Trade_Type', 'Value_USD_Mn'])

trade = df_clean.groupby('Trade_Type')['Value_USD_Mn'].sum()
trade = trade.reindex(['Import', 'Export'], fill_value=0)

if trade.sum() == 0:
    st.warning("No data available")
else:
    import plotly.express as px

    # convert to dataframe
    trade_df = trade.reset_index()
    trade_df.columns = ['Trade_Type', 'Value']

    # 🔥 Donut chart
    fig = px.pie(
        trade_df,
        names='Trade_Type',
        values='Value',
        hole=0.5,
        color='Trade_Type',
        color_discrete_map={
            'Import': '#81C784',
            'Export': '#FFAB91'
        }
    )

    fig.update_layout(
        height=260,
        margin=dict(l=10, r=10, t=40, b=10),
        showlegend=False
    )

    # 🔁 Layout: Left (Donut) + Right (Values)
    left, right = st.columns([1,1])

    with left:
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.markdown("### Trade Summary")

        import_val = trade.get('Import', 0)
        export_val = trade.get('Export', 0)

        st.metric("Import", f"{int(import_val):,}")
        st.metric("Export", f"{int(export_val):,}")



# ---------------- ROW 2 ----------------

col6, col7 = st.columns(2)

# 🟣 Top 5 Graph (Own Filter)

with col6:
    st.subheader("Top 5 Trading Analysis")

view2 = st.selectbox("View By", ["Country", "Partner"], key="g3")

if view2 == "Country":
    top = df.groupby('Partner')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)
else:
    top = df.groupby('Country')['Value_USD_Mn'].sum().sort_values(ascending=False).head(5)

top_df = top.reset_index()
top_df.columns = ['Name', 'Value']

fig = px.bar(
    top_df,
    x='Name',
    y='Value',
    color='Name',
    color_discrete_sequence=px.colors.qualitative.Set2
)

fig.update_layout(xaxis_showticklabels=False)
fig.update_layout(height=300)   # 👈 control size
st.plotly_chart(fig, use_container_width=False)

st.markdown("---")


# Top 5 Commodities

st.subheader("Top 5 Commodities")

# get top 5
top_com = df.groupby('Commodity_Name')['Value_USD_Mn'] \
            .sum() \
            .sort_values(ascending=False) \
            .head(5)

# convert to dataframe
top_com_df = top_com.reset_index()
top_com_df.columns = ['Commodity', 'Value']

# plot
fig = px.bar(
    top_com_df,
    x='Commodity',
    y='Value',
    color='Commodity',
    color_discrete_sequence=px.colors.qualitative.Set3
)

fig.update_layout(
    height=250,
    xaxis_showticklabels=False,
    margin=dict(l=10, r=10, t=30, b=10)
)

st.plotly_chart(fig, use_container_width=True)



# 🔵 LEFT → Commodity + Country + Partner (PLOTLY VERSION)
st.subheader("Commodity Analysis")

left, right = st.columns(2)


with left:
    st.markdown("#### Commodity + Country + Partner")

    f1, f2, f3 = st.columns(3)

    with f1:
        commodity_cp = st.selectbox("Commodity", df['Commodity_Name'].unique(), key="cp1")

    with f2:
        country_cp = st.selectbox("Country", df['Country'].unique(), key="cp2")

    with f3:
        partner_cp = st.selectbox("Partner", df['Partner'].unique(), key="cp3")

    df_cp = df[
        (df['Commodity_Name'] == commodity_cp) &
        (df['Country'] == country_cp) &
        (df['Partner'] == partner_cp)
    ]

    if df_cp.empty:
        st.warning("No data available")
    else:
        total_trade = df_cp['Value_USD_Mn'].sum()

        plot_df = pd.DataFrame({
            "Category": [country_cp],
            "Value": [total_trade]
        })

        fig = px.bar(
            plot_df,
            x="Category",
            y="Value",
            color_discrete_sequence=["#A9CE82"]
        )

        fig.update_layout(
            height=275,
            margin=dict(l=10, r=10, t=30, b=10),
            xaxis_title="",
            yaxis_title="Value"
        )

        st.plotly_chart(fig, use_container_width=True)


# 🟢 RIGHT → Commodity Trend
with right:
    st.markdown("#### Commodity Trend")

    commodity = st.selectbox("Commodity Filter", df['Commodity_Name'].unique(), key="g4")

    df2 = df[df['Commodity_Name'] == commodity]

    top_com = df2.groupby('Commodity_Name')['Value_USD_Mn'].sum()

    top_com_df = top_com.reset_index()
    top_com_df.columns = ['Commodity', 'Value']

    fig = px.bar(
        top_com_df,
        x='Commodity',
        y='Value',
        color='Commodity',
        color_discrete_sequence=["#DEC16A"]
    )

    fig.update_layout(
        height=250,
        margin=dict(l=10, r=10, t=30, b=10),
        xaxis_showticklabels=False
    )

    st.plotly_chart(fig, use_container_width=True)



# ---------------- TREND GRAPH ----------------

st.subheader("Trade Trend & Prediction")

# 1️⃣ Select Type
mode = st.selectbox("Select Analysis Type", ["Country", "Partner"])

# 2️⃣ Dynamic Selection
if mode == "Country":
    selected = st.selectbox("Select Country", df['Country'].unique())
    df_t = df[df['Country'] == selected].reset_index(drop=True)

else:
    selected = st.selectbox("Select Partner", df['Partner'].unique())
    df_t = df[df['Partner'] == selected].reset_index(drop=True)


# ❗ HANDLE EMPTY DATA (VERY IMPORTANT)
if df_t.empty or len(df_t) < 2:
    st.warning("Not enough data to show trend")
else:
    df_t['Month_Num'] = range(len(df_t))

    X = df_t[['Month_Num']]
    y = df_t['Value_USD_Mn']

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)

    df_t['Predicted'] = model.predict(X)


import plotly.graph_objects as go

fig = go.Figure()

# Actual line
fig.add_trace(go.Scatter(
    x=df_t['Month_Num'],
    y=df_t['Value_USD_Mn'],
    mode='lines+markers',
    name='Actual',
    line=dict(color='#4CAF50', width=2)
))

# Predicted line
fig.add_trace(go.Scatter(
    x=df_t['Month_Num'],
    y=df_t['Predicted'],
    mode='lines',
    name='Predicted',
    line=dict(color='#FF9800', width=2, dash='dash')
))

fig.update_layout(
    title=f"{mode}: {selected}",
    height=400,
    margin=dict(l=20, r=20, t=40, b=20),
    xaxis_title="Time",
    yaxis_title="Value",
    showlegend=True
)

st.plotly_chart(fig, use_container_width=True)